# @kokoro/iam-client

`@kokoro/iam-client` 是 Kokoro 内部服务调用 IAM 的版本化 TypeScript SDK。它从 IAM owner 的
`contract/openapi/iam.internal.v1.json` 生成，并在生成 API 之上提供一个薄的 `IamClient` class。

```ts
import { IamClient } from "@kokoro/iam-client";

const iam = new IamClient({
  baseUrl: "https://iam.internal.example",
  bearerToken: process.env.IAM_ACCESS_TOKEN,
});

const tenant = await iam.getTenant({ tenantId: "TENANT" });
console.log(tenant.body.data);
```

SDK 不负责登录、token refresh、JWT 签发或缓存。调用方管理 Bearer 生命周期；每次调用也可覆盖默认 Bearer、request ID、deadline 和
AbortSignal。`updateTenantStatus` 必须显式传入从状态读取返回的强 ETag，且 SDK 不自动重试写操作。

本包只开放 package 根入口。`src/api/` 是工具生成实现，不是稳定 deep-import API。

`verifyBillingAuthorization({ accessToken }, options)` 接收 Billing user access token；默认/每次调用的 bearerToken 必须是持有 `iam:billing-authorization.verify` 的 IAM tenant-machine token，两者不可互换。
本方法不自动重试，包括 503；一次 SDK 调用只请求一次当前授权决定。响应保留原 token 的 UTC expires_at，decision_ref 只关联 IAM 审计，不是付款授权凭证；consumer 不缓存 allowed，不从 body 自选 payer/tenant。

`verifySessionAuthorization(options?)` 没有 request 参数，也不发送 body/query；Bearer 必须是持有
`iam:session-authorization.verify` 的 IAM user-delegated token。该方法不自动重试或缓存，包括 503；返回的 `allowed:true` 只证明 token 所指
User、Session、client、Tenant 与 membership 在本次 IAM 快照中有效，不授予任何 Product 资源访问。

`verifyExecutionAuthorization({ executionProof, expectedOperation, expectedRequestBindingSha256 }, options)` 只接受 Agent 签发的 opaque proof
与 Platform 重算的 operation/binding；Bearer 必须是持有独占 `iam:execution-authorization.verify` scope 的 purpose-bound Platform
tenant-machine client。SDK 在传输前按 UTF-8 bytes 拒绝超过 16 KiB 的 proof，不缓存决定；成功的 `caller_client_id` 是 IAM 对当前凭据的
受信读回，`decision_ref` 是本次 AuditEvent ID，不是可复用授权凭据。仅当调用方显式配置一次只读重试时，SDK 才会在契约允许的网络/
429/503 条件下复用同一 proof、operation、binding 与 request ID；IAM 仍生成新的 current-state decision。
