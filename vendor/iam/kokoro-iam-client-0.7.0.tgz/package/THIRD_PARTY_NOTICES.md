# Third-party notices

This package is generated and built with the following MIT-licensed software:

- `@hey-api/openapi-ts` 0.99.0 — Copyright Hey API contributors.
- `zod` 4.5.4 — Copyright Colin McDonnell and contributors.

Their license texts and source distributions are available from their respective published packages and repositories.
